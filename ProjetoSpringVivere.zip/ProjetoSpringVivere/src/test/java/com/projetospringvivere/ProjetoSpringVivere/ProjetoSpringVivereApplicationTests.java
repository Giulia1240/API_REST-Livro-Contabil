package com.projetospringvivere.ProjetoSpringVivere;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoSpringVivereApplicationTests {

	@Test
	void contextLoads() {
	}

}
