package com.projetospringvivere.ProjetoSpringVivere;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ProjetoSpringVivereApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoSpringVivereApplication.class, args);
	}

	
}
